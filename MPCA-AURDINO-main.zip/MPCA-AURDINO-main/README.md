# MPCA-AURDINO

this is a simple aurdino based project wherein it comprises of 4 different sensors namely flame,temperature,smoke,gas,led display this mainly focuses on incoming threats and detects it and sends signals to buzzers which alarms the respective detected threat 
