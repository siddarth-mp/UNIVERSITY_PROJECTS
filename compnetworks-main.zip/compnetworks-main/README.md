# compnetworks

this is a simple team project focusing on socket programming in computer networks , here we have included 3 components i.e port scanning using netcat which displays all open ports and its status and have also executes file transmission service across 2 systems and also implemented chat server system , wherein 2 systems can communicate via sockets 
