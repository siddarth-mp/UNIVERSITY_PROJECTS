# project-c
bid(auction)
this is a simple c program that performs online auction/bidding system , which takes in bids and sets timer within which another user can bid  or else item will be sold to highrest bid 
