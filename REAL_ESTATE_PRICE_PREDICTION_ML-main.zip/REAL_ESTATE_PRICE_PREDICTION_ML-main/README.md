# REAL_ESTATE_PRICE_PREDICTION_ML
This is a simple REal estate price prediction project wherein I have worke on few datasets and anlysed it and trained the model using linear regression method to predict the output and the results were fairly good altough it can be integrated with front end part and serves for a higher level of project.  And also I'm uploading other data science projects

