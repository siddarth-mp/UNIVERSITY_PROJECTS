# Python_DeepLearning

this is a simple project wherein I've worked on dataset and found some result where ANN failed but I noticed how CNN does the job better when processing images
