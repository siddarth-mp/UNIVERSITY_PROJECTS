# Hotstar-clone-frontend

This is a simple front end project of cloning Disney+Hotstar using html,css ,Js only I wanted to try without using react and gave it a try and came as expected , images,videos have been provided any suggestions are welcomed , Im developing back end for the same 
