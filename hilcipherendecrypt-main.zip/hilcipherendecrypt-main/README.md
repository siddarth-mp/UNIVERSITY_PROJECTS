# hilcipherendecrypt

this is a simple python program that is used to encrypt and decrypt a plain text to encrypted message it uses a key matrix , a key matrix is basically an encoding schema of a plain text letters so that they are encoded in form of a matrix , based on formulaes we can find encrypted message , 
for decryption we need to find inverse be it gauss jordan method or any known methos we employ to find inverse 
here key matrix need to be square matrix always , if its recta ngular matrix , then it poses restriction on plain text matrix likewise it should be multiplicative compatible
