# OSCOURSE

here i have completed a course in Linux's basic software development program known as  LFD103 , "A Beginner's guide to linux kernel development " as a part of OS concepts
and I have also shared a project which displays current files , directories  and processes running in/present in a given path in tree structure i.e in hierrarchial way  , it also represents status of the file ,accessibilty permissions and other necessary informations.
